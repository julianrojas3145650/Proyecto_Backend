export class Supply {}
