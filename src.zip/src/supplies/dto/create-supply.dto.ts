export class CreateSupplyDto {}
