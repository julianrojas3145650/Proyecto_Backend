export class SupplyCategory {}
