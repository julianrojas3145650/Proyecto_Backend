export class CreateSupplyCategoryDto {}
