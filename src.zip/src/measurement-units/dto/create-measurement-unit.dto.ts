export class CreateMeasurementUnitDto {}
