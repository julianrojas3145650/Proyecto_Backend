export class Permission {}
