export class CreateFeedingDto {}
