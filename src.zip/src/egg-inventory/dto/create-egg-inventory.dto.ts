export class CreateEggInventoryDto {}
