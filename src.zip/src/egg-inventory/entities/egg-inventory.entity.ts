export class EggInventory {}
